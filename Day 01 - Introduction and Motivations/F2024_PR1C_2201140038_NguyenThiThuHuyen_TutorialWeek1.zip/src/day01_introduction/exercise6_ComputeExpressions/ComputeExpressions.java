package day01_introduction.exercise6_ComputeExpressions;

public class ComputeExpressions {
    public static void main(String[] args) {
        System.out.println((12.5 * 5.0 + 5.5) / (4.5 + 2.0 * 3.5));
        System.out.println((12.5 * 5.0 + 5.5) / (4.5 + 2.0 * 3.5));
    }
}

