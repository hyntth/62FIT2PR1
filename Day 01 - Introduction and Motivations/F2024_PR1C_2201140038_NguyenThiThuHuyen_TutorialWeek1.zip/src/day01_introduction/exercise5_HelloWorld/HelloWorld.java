package day01_introduction.exercise5_HelloWorld;

public class HelloWorld {
    public static void main(String[] args) {
        // Print out "Hello, World"
        System.out.println("Hello, World!"); //
    }
}